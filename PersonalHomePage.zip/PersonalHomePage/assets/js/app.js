// assets/js/app.js - simple junior-style script (LocalStorage)
(function(){
  var STORAGE_KEY = 'ph_posts';
  var postsList = document.getElementById('postsList');
  var newPostBtn = document.getElementById('newPostBtn');
  var postModal = new bootstrap.Modal(document.getElementById('postModal'));
  var viewModal = new bootstrap.Modal(document.getElementById('viewModal'));
  var postId = document.getElementById('postId');
  var tInput = document.getElementById('postTitle');
  var aInput = document.getElementById('postAuthor');
  var cInput = document.getElementById('postContent');
  var mediaInput = document.getElementById('postMedia');
  var mediaPreview = document.getElementById('mediaPreview');
  var linksContainer = document.getElementById('linksContainer');
  var addLinkBtn = document.getElementById('addLinkBtn');
  var saveBtn = document.getElementById('savePostBtn');
  var viewTitle = document.getElementById('viewTitle');
  var viewMeta = document.getElementById('viewMeta');
  var viewContent = document.getElementById('viewContent');
  var viewMedia = document.getElementById('viewMedia');
  var viewLinks = document.getElementById('viewLinks');
  var deleteBtn = document.getElementById('deletePostBtn');

  function load(){ try{ var raw = localStorage.getItem(STORAGE_KEY); return raw?JSON.parse(raw):[] }catch(e){return []} }
  function save(d){ localStorage.setItem(STORAGE_KEY, JSON.stringify(d)) }
  function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,8) }

  var curMedia = [] // {id, data}

  function escapeHtml(s){ return (s+'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') }

  function render(){
    var posts = load();
    var html = '';
    for(var i=0;i<posts.length;i++){
      var p = posts[i];
      html += '<a class="list-group-item list-group-item-action" data-id="'+p.id+'">';
      html += '<div class="d-flex w-100 justify-content-between"><h5 class="mb-1">'+escapeHtml(p.title)+'</h5>';
      html += '<small class="post-meta">'+new Date(p.date).toLocaleDateString()+'</small></div>';
      html += '<p class="mb-1">'+escapeHtml((p.content||'').substring(0,200))+(p.content&&p.content.length>200?'...':'')+'</p></a>';
    }
    if(postsList) postsList.innerHTML = html;
    if(postsList){ var items = postsList.querySelectorAll('a[data-id]'); for(var j=0;j<items.length;j++){ items[j].addEventListener('click', function(){ openPost(this.getAttribute('data-id')) }) } }
  }

  // handle media input
  mediaInput && mediaInput.addEventListener('change', function(e){
    var files = e.target.files;
    for(var i=0;i<files.length;i++){
      (function(f){
        var r = new FileReader();
        var mId = uid();
        r.onload = function(){
          curMedia.push({id:mId,data:r.result});
          if(mediaPreview) mediaPreview.innerHTML += '<div class="me-2" data-mid="'+mId+'"><img src="'+r.result+'" style="width:96px;height:96px;object-fit:cover" class="rounded"><br><button type="button" class="btn btn-sm btn-outline-danger remove-media mt-1">Remove</button></div>';
        };
        r.readAsDataURL(f);
      })(files[i]);
    }
  });

  // remove media (delegate)
  mediaPreview && mediaPreview.addEventListener('click', function(e){
    if(e.target && e.target.classList && e.target.classList.contains('remove-media')){
      var parent = e.target.closest('[data-mid]');
      if(!parent) return;
      var mid = parent.getAttribute('data-mid');
      curMedia = curMedia.filter(function(m){ return m.id !== mid });
      parent.parentNode && parent.parentNode.removeChild(parent);
    }
  });

  // links
  addLinkBtn && addLinkBtn.addEventListener('click', function(){
    if(!linksContainer) return;
    var div = document.createElement('div');
    div.className = 'd-flex gap-2 mb-2';
    div.innerHTML = '<input class="form-control form-control-sm" placeholder="Link title"><input class="form-control form-control-sm" placeholder="https://example.com"><button type="button" class="btn btn-sm btn-outline-danger remove-link">Remove</button>';
    linksContainer.appendChild(div);
    var btn = div.querySelector('.remove-link'); if(btn) btn.onclick = function(){ div.remove() };
  });

  // new post
  newPostBtn && newPostBtn.addEventListener('click', function(){ if(postId) postId.value=''; if(tInput) tInput.value=''; if(aInput) aInput.value=''; if(cInput) cInput.value=''; curMedia=[]; if(mediaPreview) mediaPreview.innerHTML=''; if(linksContainer) linksContainer.innerHTML=''; document.getElementById('postModalTitle').textContent='New Post'; postModal.show(); })

  // save post
  saveBtn && saveBtn.addEventListener('click', function(){
    if(!tInput || !cInput) return;
    if(!tInput.value.trim()||!cInput.value.trim()){ alert('Please add title and content'); return }
    var posts = load();
    var id = (postId && postId.value) || uid();
    var mediaData = curMedia.map(function(m){ return m.data });
    var entry = { id: id, title: tInput.value.trim(), author: (aInput.value.trim()||'Anonymous'), date: new Date().toISOString(), content: cInput.value, media: mediaData, links: [] };
    if(linksContainer){ var rows = linksContainer.querySelectorAll('div'); for(var r=0;r<rows.length;r++){ var ins = rows[r].querySelectorAll('input'); if(ins.length>=2 && ins[1].value.trim()){ entry.links.push({ title: (ins[0].value.trim()||ins[1].value.trim()), url: ins[1].value.trim() }) } } }
    posts.unshift(entry); save(posts); postModal.hide(); render();
  });

  // delete from view
  deleteBtn && deleteBtn.addEventListener('click', function(){ var id = this.getAttribute('data-id'); if(!id) return; if(!confirm('Delete?')) return; var posts = load(); var out = []; for(var i=0;i<posts.length;i++){ if(posts[i].id!=id) out.push(posts[i]) } save(out); viewModal.hide(); render(); })

  function openPost(id){ var posts = load(); var p=null; for(var i=0;i<posts.length;i++){ if(posts[i].id==id) p=posts[i] } if(!p) return; if(viewTitle) viewTitle.textContent = p.title; if(viewMeta) viewMeta.textContent = 'By '+(p.author||'Anonymous')+' • '+new Date(p.date).toLocaleString(); if(viewContent) viewContent.textContent = p.content; if(viewMedia) viewMedia.innerHTML=''; if(viewLinks) viewLinks.innerHTML=''; if(p.media && viewMedia){ for(var m=0;m<p.media.length;m++){ viewMedia.innerHTML += '<img src="'+p.media[m]+'" class="img-thumbnail me-2" style="width:160px;height:120px;object-fit:cover" />' } } if(p.links && viewLinks){ var list = '<ul class="list-unstyled">'; for(var q=0;q<p.links.length;q++){ list += '<li><a href="'+p.links[q].url+'" target="_blank" rel="noopener noreferrer">'+escapeHtml(p.links[q].title||p.links[q].url)+'</a></li>' } list += '</ul>'; viewLinks.innerHTML = list } if(deleteBtn) deleteBtn.setAttribute('data-id', p.id); viewModal.show(); }

  document.addEventListener('DOMContentLoaded', function(){ render(); })

})();

